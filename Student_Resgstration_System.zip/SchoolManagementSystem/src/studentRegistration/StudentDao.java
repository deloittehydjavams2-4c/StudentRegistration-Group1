package studentRegistration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class StudentDao {

int counter;
int records;

@Autowired
JdbcTemplate template;

//@SuppressWarnings("deprecation")
public int retrieveTotalRegistrations() {

String query = "select count(*) from student_info";
records = template.queryForObject(query, Integer.class);

return records;

}
public boolean insertStudent(Student_Info std) {
	
String query = "insert into student_info values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		 // String query1="insert into country_info values(?,?,?)"; 
		 // String query2="insert into fees_info values(?,?,?,?)";
		 
java.sql.Date sqlDate=new java.sql.Date(std.getDate_Of_Birth().getTime());
Object args[] = { std.getStudent_Id(), std.getStudent_Name(),sqlDate ,Character.toString(std.getGuardian_Type()),
std.getGuardian_Name(), std.getAddress(), std.getCountry_Id(), std.getContact_No(), std.getMail_Id(),Character.toString(std.getGender()),
std.getStandard(),  Character.toString(std.getStandard_category()), Character.toString(std.getTransport()), std.getNet_Fees() };

//Object args1[]= {std.getCountry().getCountry_Id(),std.getCountry().getCountry_Name(),std.getCountry().getState_Name()};
//Object args2[]= {std.getFees().getStandard(),std.getFees().getAge(),std.getFees().getStdfees(),std.getFees().getTransportFee()};
template.update(query, args);
//template.update(query1,args1);
//template.update(query2,args2);
return true;
}


public double retrieveFees(Fees_Info feesInfo) {
return  feesInfo.getStdfees()+feesInfo.getTransportFee();
}
}