package studentRegistration;

public class SchoolBusinessException extends RuntimeException {
	public SchoolBusinessException(String message) {
		super(message);
	}
}
