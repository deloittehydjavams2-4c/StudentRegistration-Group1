package studentRegistration;

import org.springframework.stereotype.Component;

@Component
public class Fees_Info {
	private String standard;
	private int age;
	private double stdfees;
	private double transportFee;
	public String getStandard() {
	return standard;
	}
	public void setStandard(String standard) {
	this.standard = standard;
	}
	public int getAge() {
	return age;
	}
	public void setAge(int age) {
	this.age = age;
	}
	public double getStdfees() {
	return stdfees;
	}
	public void setStdfees(double stdfees) {
	this.stdfees = stdfees;
	}
	public double getTransportFee() {
	return transportFee;
	}
	public void setTransportFee(double transportFee) {
	this.transportFee = transportFee;
	}
}
