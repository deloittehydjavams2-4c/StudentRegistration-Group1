package studentRegistration;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Component
public class RegistrationBO {	
	public boolean registerStudent(Student_Info std) throws SchoolBusinessException,ParseException {
		int flag=0;
		//Validating student name
		String name=std.getStudent_Name();
		for(int i=0;i<name.length();i++) {
			char ch=name.charAt(i);
			if(!(Character.isLetter(ch) || ch == ' '))
				flag=1;
		}
		if(flag==1) {
			throw new SchoolBusinessException("501");
		}
		
		//Validating empty fields
		if(std.getStudent_Name()==null||std.getDate_Of_Birth()==null||std.getGuardian_Type()==0||std.getGuardian_Name()==null||
					std.getAddress()==null||std.getCountry_Id()==null||std.getContact_No()==0||std.getMail_Id()==null||
					std.getGender()==0||std.getStandard()==null||std.getStandard_category()==0||std.getTransport()==0||
					std.getNet_Fees()==0)
			flag=1;
		if(flag==1) {
			throw new SchoolBusinessException("0");
		}
		
		
		//Validating email id
			int at=0;
			int dot=0;
			String email=std.getMail_Id();
			for(int i=0;i<email.length();i++) {
				if(email.charAt(i)=='@')
					at++;
				else if(email.charAt(i)=='.')
					dot++;
			}
			if(!(at==1||dot==1))
				flag=1;
			if(flag==1) {
				throw new SchoolBusinessException("502");
			}
		//Validating contact number
			Pattern pattern=Pattern.compile("\\d{10}");
			String s=Long.toString(std.getContact_No());
			Matcher matcher=pattern.matcher(s);
			if(!matcher.matches())
				throw new SchoolBusinessException("506");
		
		//Validating Date of Birth
			Date today=new Date();
			SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
			String date_today=sdf.format(today);
			Date d1=sdf.parse(date_today);
			String dob=sdf.format(std.getDate_Of_Birth());
			Date d2=sdf.parse(dob);
			if(d1.compareTo(d2)<=0)
				throw new SchoolBusinessException("504");
		//Comparing age with standard
			int grade=0;
			if(std.getStandard()=="I")
				grade=1;
			else if(std.getStandard()=="II")
				grade=2;
			else if(std.getStandard()=="III")
				grade=3;
			else if(std.getStandard()=="IV")
				grade=4;
			else if(std.getStandard()=="V")
				grade=5;
			else if(std.getStandard()=="VI")
				grade=6;
			else if(std.getStandard()=="VII")
				grade=7;
			else if(std.getStandard()=="VIII")
				grade=8;
			else if(std.getStandard()=="IX")
				grade=9;
			else if(std.getStandard()=="X")
				grade=10;
			else if(std.getStandard()=="XI")
				grade=11;
			else if(std.getStandard()=="XII")
				grade=12;
			
			String dob_year=dob.substring(0, 4);
			String today_year=date_today.substring(0, 4);
			int y1=Integer.parseInt(today_year)-Integer.parseInt(dob_year);
			if(!(y1== grade+4 || y1==grade+5))
				throw new SchoolBusinessException("503");
	
			
				
		return true;
	}
}
