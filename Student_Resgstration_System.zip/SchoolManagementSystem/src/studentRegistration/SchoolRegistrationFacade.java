package studentRegistration;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SchoolRegistrationFacade {
	@Autowired
	StudentDao dao;
	@Autowired
	Student_Info std;
	@Autowired
	RegistrationBO rbo;
	@Autowired
	Country_Info cnf;
	@Autowired
	Fees_Info fin;
	
	@RequestMapping(value = "ss", method = RequestMethod.GET)
	public String showSuccessScreen() {
		return "SuccessScreen";
	}
	
	@RequestMapping(value = "addstd", method = RequestMethod.GET)
	public String showAddStudentForm() { 
		return "RegisterStudentScreen"; 
		}
	
	//@ModelAttribute("student_Info") Student_Info std
	  @RequestMapping(value="addstd",method=RequestMethod.POST) 
	  public ModelAndView addStudent(HttpServletRequest req) throws SchoolBusinessException,ParseException{ 
		  System.out.println(req.getParameter("country"));
		  String transport=req.getParameter("transport");
		  String country = req.getParameter("country");
		  String state = req.getParameter("state");
		  cnf.setCountry_Name(req.getParameter("country"));
		  cnf.setState_Name(req.getParameter("state"));
		 System.out.println(cnf.getState_Name());
		  
		  if (req.getParameter("country").equals("india")) {
		  if (req.getParameter("state").equals("Tamil Nadu"))
		  {System.out.println("insdide if");
			  String id="C01";
			  cnf.setCountry_Id(id);
		  std.setCountry_Id(id);}
		  if (state.equals("Kerala"))
		  {cnf.setCountry_Id("C02");
		  std.setCountry_Id("C02");}
		  if (state.equals("Karnataka"))
		  {std.setCountry_Id("C03");
		  cnf.setCountry_Id("C03");
		  }
		  if (state.equals("Andhra Pradesh"))
		  {  std.setCountry_Id("C04");
		  cnf.setCountry_Id("C04");
		  }}
		  else if (country.equals("uk")) {
		  cnf.setCountry_Id("C05");
		  std.setCountry_Id("C05");
		  } else if (country.equals("usa")) {
		  cnf.setCountry_Id("C06");
		  std.setCountry_Id("C06");
		  } else if (country.equals("italy")) {
		  cnf.setCountry_Id("C07");
		  std.setCountry_Id("C07");
		  }
		  System.out.println(std.getCountry_Id());
		  std.setCountry(cnf);
		  
		  int record=dao.retrieveTotalRegistrations();
		  int counter = record + 1;
		  String student_Id = "R" + counter;
		  std.setStudent_Id(student_Id);
		  
		  
		  
		  String standard = req.getParameter("standard");
		  
		  if (standard.equals("I") || standard.equals("II") || standard.equals("III") || standard.equals("IV")
		  || standard.equals("V"))
		  std.setStandard_category('P');
		  else if (standard.equals("VI") || standard.equals("VII") || standard.equals("VIII") || standard.equals("IX")
		  || standard.equals("X"))
		  std.setStandard_category('S');
		  else
		  std.setStandard_category('H');
		  
		  
		  double standardFees;
		  
		  double transportFees=1200;
		  if (standard.equals("I"))
		  {
			  System.out.println("(((((((");
			  standardFees = 18000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("II"))
		  {standardFees = 20000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("III"))
		  {  standardFees = 22000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("IV"))
		  { standardFees = 24000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("V"))
		  {standardFees = 26000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("VI"))
		  {standardFees = 28000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("VII"))
		  {standardFees = 30000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("VIII"))
		  {standardFees = 32000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("IX"))
		  {standardFees = 34000;
		  fin.setStdfees(standardFees);}
		  else if (standard.equals("X"))
		  {standardFees = 40000;
		  fin.setStdfees(standardFees);}
		  
		  else if (standard.equals("XI"))
		  {standardFees = 45000;
		  fin.setStdfees(standardFees);}
		  else 
		  {standardFees = 50000;
		  fin.setStdfees(standardFees);}
		 
		  switch (transport.charAt(0)) {
		  case 'Y':
			  fin.setTransportFee(1200);
		  std.setNet_Fees(standardFees+transportFees);
		  case 'N':
			  fin.setTransportFee(0);
		  std.setNet_Fees(standardFees);
		  }
		  
		 Date today=new Date(); 
		 SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
		 String date_today=sdf.format(today);
		/*
		 * Date dob1=sdf.parse(req.getParameter("Date_Of_Birth")); System.out.println();
		 * String dob=sdf.format(dob1); String dob_year=dob.substring(0, 4); String
		 * today_year=date_today.substring(0, 4); int
		 * age=Integer.parseInt(today_year)-Integer.parseInt(dob_year);
		 */
			fin.setAge(13);
			fin.setStandard(standard);
			
			std.setFees(fin);
			
		std.setStudent_Name(req.getParameter("student_Name"));	
std.setDate_Of_Birth(sdf.parse(req.getParameter("date_Of_Birth")));
String gd=req.getParameter("guardian_type");
std.setGuardian_Type('p');
std.setGuardian_Name(req.getParameter("guardian_Name"));
std.setAddress(req.getParameter("address"));
long cn=Long.parseLong(req.getParameter("contact_No"));
std.setContact_No(cn);
std.setMail_Id(req.getParameter("mail_Id"));
String gender=req.getParameter("gender");
std.setGender('f');
std.setStandard(standard);
std.setTransport('Y');
		  ModelAndView mav=new ModelAndView();
		  System.out.println(std.getStudent_Id());
		 // rbo.registerStudent(std);
		  dao.insertStudent(std);
		  mav.setViewName("SuccessScreen");
		  
		 
	  return mav; }

}
